package vectorwing.farmersdelight.client.recipebook;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.util.StringRepresentable;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ByIdMap;
import java.util.function.IntFunction;

import java.util.EnumSet;
import net.minecraft.util.StringRepresentable;
import org.jetbrains.annotations.NotNull;

public enum CookingPotRecipeBookTab implements StringRepresentable
{
	MEALS("meals"),
	DRINKS("drinks"),
	MISC("misc");

	public static final Codec<CookingPotRecipeBookTab> CODEC = Codec.STRING.flatXmap(s -> {
		CookingPotRecipeBookTab tab = findByName(s);
		if (tab == null) {
			return DataResult.error(() -> "Optional field 'recipe_book_tab' does not match any valid tab. If defined, must be one of the following: " + EnumSet.allOf(CookingPotRecipeBookTab.class));
		}
		return DataResult.success(tab);
	}, tab -> DataResult.success(tab.toString()));
	public static final IntFunction<CookingPotRecipeBookTab> BY_ID = ByIdMap.continuous(CookingPotRecipeBookTab::ordinal, values(), ByIdMap.OutOfBoundsStrategy.ZERO);
	public static final StreamCodec<ByteBuf, CookingPotRecipeBookTab> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, CookingPotRecipeBookTab::ordinal);

	public final String name;

	CookingPotRecipeBookTab(String name) {
		this.name = name;
	}

	public static CookingPotRecipeBookTab findByName(String name) {
		for (CookingPotRecipeBookTab value : values()) {
			if (value.name.equals(name)) {
				return value;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return this.name;
	}

	@Override
	public @NotNull String getSerializedName() {
		return this.name;
	}
}
